create definer = root@localhost trigger update_stu_class_id
    after update
    on t_student
    for each row
BEGIN
         UPDATE t_stu_grade
         SET t_stu_grade.stu_class_id = NEW.stu_class_id
         WHERE t_stu_grade.stu_class_id = OLD.stu_class_id AND t_stu_grade.`name` = OLD.`name`;
     END;

